/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Dawid/Desktop/calculator-with-rs232/calculator-with-rs232-main/rs232/test_rs232_receiver.vhd";



static void work_a_0406427775_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 3432U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(93, ng0);
    t2 = (t0 + 4064);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(94, ng0);
    t2 = (t0 + 1968U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3240);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(95, ng0);
    t2 = (t0 + 4064);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(96, ng0);
    t2 = (t0 + 1968U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3240);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_0406427775_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int64 t4;
    int64 t5;
    int64 t6;
    int64 t7;
    int t8;
    int t9;
    char *t10;
    char *t11;
    int t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    int t24;
    int t25;
    int t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    char *t33;

LAB0:    t1 = (t0 + 3680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(103, ng0);
    t2 = (t0 + 2088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t5 = (1.2500000000000000 * t4);
    t6 = (2 * 1000LL);
    t7 = (t5 + t6);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, t7);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(106, ng0);
    t2 = (t0 + 7794);
    *((int *)t2) = 0;
    t3 = (t0 + 7798);
    *((int *)t3) = 9;
    t8 = 0;
    t9 = 9;

LAB8:    if (t8 <= t9)
        goto LAB9;

LAB11:    xsi_set_current_line(110, ng0);
    t2 = (t0 + 4128);
    t3 = (t2 + 56U);
    t10 = *((char **)t3);
    t11 = (t10 + 56U);
    t17 = *((char **)t11);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 2088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t5 = (2 * t4);
    t6 = (1 * 1000LL);
    t7 = (t5 + t6);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, t7);

LAB19:    *((char **)t1) = &&LAB20;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB9:    xsi_set_current_line(107, ng0);
    t10 = (t0 + 2208U);
    t11 = *((char **)t10);
    t10 = (t0 + 7794);
    t12 = *((int *)t10);
    t13 = (t12 - 9);
    t14 = (t13 * -1);
    xsi_vhdl_check_range_of_index(9, 0, -1, *((int *)t10));
    t15 = (1U * t14);
    t16 = (0 + t15);
    t17 = (t11 + t16);
    t18 = *((unsigned char *)t17);
    t19 = (t0 + 4128);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    *((unsigned char *)t23) = t18;
    xsi_driver_first_trans_fast(t19);
    xsi_set_current_line(108, ng0);
    t2 = (t0 + 2088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, t4);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB10:    t2 = (t0 + 7794);
    t8 = *((int *)t2);
    t3 = (t0 + 7798);
    t9 = *((int *)t3);
    if (t8 == t9)
        goto LAB11;

LAB16:    t12 = (t8 + 1);
    t8 = t12;
    t10 = (t0 + 7794);
    *((int *)t10) = t8;
    goto LAB8;

LAB12:    goto LAB10;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

LAB17:    xsi_set_current_line(114, ng0);
    t2 = (t0 + 7802);
    *((int *)t2) = 1;
    t3 = (t0 + 7806);
    *((int *)t3) = 5;
    t8 = 1;
    t9 = 5;

LAB21:    if (t8 <= t9)
        goto LAB22;

LAB24:    xsi_set_current_line(120, ng0);
    t2 = (t0 + 2088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t5 = (2 * t4);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, t5);

LAB37:    *((char **)t1) = &&LAB38;
    goto LAB1;

LAB18:    goto LAB17;

LAB20:    goto LAB18;

LAB22:    xsi_set_current_line(115, ng0);
    t10 = (t0 + 7810);
    *((int *)t10) = 0;
    t11 = (t0 + 7814);
    *((int *)t11) = 9;
    t12 = 0;
    t13 = 9;

LAB25:    if (t12 <= t13)
        goto LAB26;

LAB28:
LAB23:    t2 = (t0 + 7802);
    t8 = *((int *)t2);
    t3 = (t0 + 7806);
    t9 = *((int *)t3);
    if (t8 == t9)
        goto LAB24;

LAB34:    t12 = (t8 + 1);
    t8 = t12;
    t10 = (t0 + 7802);
    *((int *)t10) = t8;
    goto LAB21;

LAB26:    xsi_set_current_line(116, ng0);
    t17 = (t0 + 2328U);
    t19 = *((char **)t17);
    t17 = (t0 + 7810);
    t24 = *((int *)t17);
    t25 = (t24 - 9);
    t14 = (t25 * -1);
    xsi_vhdl_check_range_of_index(9, 0, -1, *((int *)t17));
    t15 = (1U * t14);
    t20 = (t0 + 7802);
    t26 = *((int *)t20);
    t27 = (t26 - 1);
    t16 = (t27 * 1);
    xsi_vhdl_check_range_of_index(1, 5, 1, *((int *)t20));
    t28 = (10U * t16);
    t29 = (0 + t28);
    t30 = (t29 + t15);
    t21 = (t19 + t30);
    t18 = *((unsigned char *)t21);
    t22 = (t0 + 4128);
    t23 = (t22 + 56U);
    t31 = *((char **)t23);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = t18;
    xsi_driver_first_trans_fast(t22);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 2088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, t4);

LAB31:    *((char **)t1) = &&LAB32;
    goto LAB1;

LAB27:    t2 = (t0 + 7810);
    t12 = *((int *)t2);
    t3 = (t0 + 7814);
    t13 = *((int *)t3);
    if (t12 == t13)
        goto LAB28;

LAB33:    t24 = (t12 + 1);
    t12 = t24;
    t10 = (t0 + 7810);
    *((int *)t10) = t12;
    goto LAB25;

LAB29:    goto LAB27;

LAB30:    goto LAB29;

LAB32:    goto LAB30;

LAB35:    xsi_set_current_line(123, ng0);
    t2 = (t0 + 7818);
    *((int *)t2) = 0;
    t3 = (t0 + 7822);
    *((int *)t3) = 3;
    t8 = 0;
    t9 = 3;

LAB39:    if (t8 <= t9)
        goto LAB40;

LAB42:    xsi_set_current_line(127, ng0);
    t2 = (t0 + 4192);
    t3 = (t2 + 56U);
    t10 = *((char **)t3);
    t11 = (t10 + 56U);
    t17 = *((char **)t11);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_delta(t2, 0U, 1, 0LL);
    t19 = (t0 + 2088U);
    t20 = *((char **)t19);
    t4 = *((int64 *)t20);
    t5 = (0.10000000000000001 * t4);
    t19 = (t0 + 4192);
    t21 = (t19 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t31 = *((char **)t23);
    *((unsigned char *)t31) = (unsigned char)2;
    xsi_driver_subsequent_trans_delta(t19, 0U, 1, t5);
    xsi_set_current_line(128, ng0);
    t2 = (t0 + 4128);
    t3 = (t2 + 56U);
    t10 = *((char **)t3);
    t11 = (t10 + 56U);
    t17 = *((char **)t11);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(131, ng0);
    t2 = (t0 + 7826);
    *((int *)t2) = 0;
    t3 = (t0 + 7830);
    *((int *)t3) = 9;
    t8 = 0;
    t9 = 9;

LAB48:    if (t8 <= t9)
        goto LAB49;

LAB51:    xsi_set_current_line(136, ng0);

LAB59:    *((char **)t1) = &&LAB60;
    goto LAB1;

LAB36:    goto LAB35;

LAB38:    goto LAB36;

LAB40:    xsi_set_current_line(124, ng0);
    t10 = (t0 + 2448U);
    t11 = *((char **)t10);
    t10 = (t0 + 7818);
    t12 = *((int *)t10);
    t13 = (t12 - 9);
    t14 = (t13 * -1);
    xsi_vhdl_check_range_of_index(9, 0, -1, *((int *)t10));
    t15 = (1U * t14);
    t16 = (0 + t15);
    t17 = (t11 + t16);
    t18 = *((unsigned char *)t17);
    t19 = (t0 + 4128);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    *((unsigned char *)t23) = t18;
    xsi_driver_first_trans_fast(t19);
    xsi_set_current_line(125, ng0);
    t2 = (t0 + 2088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, t4);

LAB45:    *((char **)t1) = &&LAB46;
    goto LAB1;

LAB41:    t2 = (t0 + 7818);
    t8 = *((int *)t2);
    t3 = (t0 + 7822);
    t9 = *((int *)t3);
    if (t8 == t9)
        goto LAB42;

LAB47:    t12 = (t8 + 1);
    t8 = t12;
    t10 = (t0 + 7818);
    *((int *)t10) = t8;
    goto LAB39;

LAB43:    goto LAB41;

LAB44:    goto LAB43;

LAB46:    goto LAB44;

LAB49:    xsi_set_current_line(132, ng0);
    t10 = (t0 + 2448U);
    t11 = *((char **)t10);
    t10 = (t0 + 7826);
    t12 = *((int *)t10);
    t13 = (t12 - 9);
    t14 = (t13 * -1);
    xsi_vhdl_check_range_of_index(9, 0, -1, *((int *)t10));
    t15 = (1U * t14);
    t16 = (0 + t15);
    t17 = (t11 + t16);
    t18 = *((unsigned char *)t17);
    t19 = (t0 + 4128);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    *((unsigned char *)t23) = t18;
    xsi_driver_first_trans_fast(t19);
    xsi_set_current_line(133, ng0);
    t2 = (t0 + 2088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t2 = (t0 + 3488);
    xsi_process_wait(t2, t4);

LAB54:    *((char **)t1) = &&LAB55;
    goto LAB1;

LAB50:    t2 = (t0 + 7826);
    t8 = *((int *)t2);
    t3 = (t0 + 7830);
    t9 = *((int *)t3);
    if (t8 == t9)
        goto LAB51;

LAB56:    t12 = (t8 + 1);
    t8 = t12;
    t10 = (t0 + 7826);
    *((int *)t10) = t8;
    goto LAB48;

LAB52:    goto LAB50;

LAB53:    goto LAB52;

LAB55:    goto LAB53;

LAB57:    goto LAB2;

LAB58:    goto LAB57;

LAB60:    goto LAB58;

}


extern void work_a_0406427775_2372691052_init()
{
	static char *pe[] = {(void *)work_a_0406427775_2372691052_p_0,(void *)work_a_0406427775_2372691052_p_1};
	xsi_register_didat("work_a_0406427775_2372691052", "isim/test_rs232_receiver_isim_beh.exe.sim/work/a_0406427775_2372691052.didat");
	xsi_register_executes(pe);
}
