/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Dawid/Desktop/calculator-with-rs232/calculator-with-rs232-main/rs232/test_register_12_synchronized.vhd";



static void work_a_2543831133_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 3072U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(84, ng0);
    t2 = (t0 + 3704);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 1968U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 2880);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(86, ng0);
    t2 = (t0 + 3704);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 1968U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 2880);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_2543831133_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    int t5;
    int t6;
    char *t7;
    char *t8;
    int t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    int64 t21;
    int64 t22;

LAB0:    t1 = (t0 + 3320U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(94, ng0);
    t3 = (2 * 1000LL);
    t2 = (t0 + 3128);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(97, ng0);
    t2 = (t0 + 7240);
    *((int *)t2) = 1;
    t4 = (t0 + 7244);
    *((int *)t4) = 3;
    t5 = 1;
    t6 = 3;

LAB8:    if (t5 <= t6)
        goto LAB9;

LAB11:    xsi_set_current_line(104, ng0);
    t2 = (t0 + 3896);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t14 = *((char **)t8);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_delta(t2, 0U, 1, 0LL);
    t15 = (t0 + 1968U);
    t16 = *((char **)t15);
    t3 = *((int64 *)t16);
    t15 = (t0 + 3896);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = (unsigned char)2;
    xsi_driver_subsequent_trans_delta(t15, 0U, 1, t3);
    xsi_set_current_line(105, ng0);
    t2 = (t0 + 1968U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t21 = (2 * 1000LL);
    t22 = (t3 + t21);
    t2 = (t0 + 3128);
    xsi_process_wait(t2, t22);

LAB19:    *((char **)t1) = &&LAB20;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB9:    xsi_set_current_line(98, ng0);
    t7 = (t0 + 2088U);
    t8 = *((char **)t7);
    t7 = (t0 + 7240);
    t9 = *((int *)t7);
    t10 = (t9 - 1);
    t11 = (t10 * 1);
    t12 = (4U * t11);
    t13 = (0 + t12);
    t14 = (t8 + t13);
    t15 = (t0 + 3768);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t14, 4U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 3832);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t14 = *((char **)t8);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_delta(t2, 0U, 1, 0LL);
    t15 = (t0 + 1968U);
    t16 = *((char **)t15);
    t3 = *((int64 *)t16);
    t15 = (t0 + 3832);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = (unsigned char)2;
    xsi_driver_subsequent_trans_delta(t15, 0U, 1, t3);
    xsi_set_current_line(100, ng0);
    t2 = (t0 + 1968U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t21 = (2 * 1000LL);
    t22 = (t3 + t21);
    t2 = (t0 + 3128);
    xsi_process_wait(t2, t22);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB10:    t2 = (t0 + 7240);
    t5 = *((int *)t2);
    t4 = (t0 + 7244);
    t6 = *((int *)t4);
    if (t5 == t6)
        goto LAB11;

LAB16:    t9 = (t5 + 1);
    t5 = t9;
    t7 = (t0 + 7240);
    *((int *)t7) = t5;
    goto LAB8;

LAB12:    goto LAB10;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

LAB17:    xsi_set_current_line(108, ng0);
    t2 = (t0 + 7248);
    *((int *)t2) = 1;
    t4 = (t0 + 7252);
    *((int *)t4) = 3;
    t5 = 1;
    t6 = 3;

LAB21:    if (t5 <= t6)
        goto LAB22;

LAB24:    xsi_set_current_line(113, ng0);

LAB32:    *((char **)t1) = &&LAB33;
    goto LAB1;

LAB18:    goto LAB17;

LAB20:    goto LAB18;

LAB22:    xsi_set_current_line(109, ng0);
    t7 = (t0 + 2088U);
    t8 = *((char **)t7);
    t7 = (t0 + 7248);
    t9 = *((int *)t7);
    t10 = (t9 - 1);
    t11 = (t10 * 1);
    t12 = (4U * t11);
    t13 = (0 + t12);
    t14 = (t8 + t13);
    t15 = (t0 + 3768);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t14, 4U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(110, ng0);
    t2 = (t0 + 1968U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t21 = (2 * 1000LL);
    t22 = (t3 + t21);
    t2 = (t0 + 3128);
    xsi_process_wait(t2, t22);

LAB27:    *((char **)t1) = &&LAB28;
    goto LAB1;

LAB23:    t2 = (t0 + 7248);
    t5 = *((int *)t2);
    t4 = (t0 + 7252);
    t6 = *((int *)t4);
    if (t5 == t6)
        goto LAB24;

LAB29:    t9 = (t5 + 1);
    t5 = t9;
    t7 = (t0 + 7248);
    *((int *)t7) = t5;
    goto LAB21;

LAB25:    goto LAB23;

LAB26:    goto LAB25;

LAB28:    goto LAB26;

LAB30:    goto LAB2;

LAB31:    goto LAB30;

LAB33:    goto LAB31;

}


extern void work_a_2543831133_2372691052_init()
{
	static char *pe[] = {(void *)work_a_2543831133_2372691052_p_0,(void *)work_a_2543831133_2372691052_p_1};
	xsi_register_didat("work_a_2543831133_2372691052", "isim/test_register_12_synchronized_isim_beh.exe.sim/work/a_2543831133_2372691052.didat");
	xsi_register_executes(pe);
}
