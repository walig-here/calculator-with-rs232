/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/lab/Desktop/ucisw-projekt-main/ucisw-projekt-main/rs232/test_rs232_receiver.vhd";
extern char *STD_STANDARD;



static void work_a_0406427775_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 3192U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(83, ng0);
    t2 = (t0 + 3824);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 1968U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3000);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(85, ng0);
    t2 = (t0 + 3824);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 1968U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3000);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_0406427775_2372691052_p_1(char *t0)
{
    char t10[16];
    char *t1;
    char *t2;
    char *t3;
    int64 t4;
    int64 t5;
    int64 t6;
    int64 t7;
    int t8;
    int t9;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    int t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned char t21;
    char *t22;

LAB0:    t1 = (t0 + 3440U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t5 = (1.2500000000000000 * t4);
    t6 = (2 * 1000LL);
    t7 = (t5 + t6);
    t2 = (t0 + 3248);
    xsi_process_wait(t2, t7);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(96, ng0);
    t2 = (t0 + 6602);
    *((int *)t2) = 0;
    t3 = (t0 + 6606);
    *((int *)t3) = 9;
    t8 = 0;
    t9 = 9;

LAB8:    if (t8 <= t9)
        goto LAB9;

LAB11:    xsi_set_current_line(101, ng0);
    t2 = (t0 + 3888);
    t3 = (t2 + 56U);
    t11 = *((char **)t3);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(103, ng0);

LAB19:    *((char **)t1) = &&LAB20;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB9:    xsi_set_current_line(97, ng0);
    t11 = ((STD_STANDARD) + 384);
    t12 = (t0 + 6602);
    t13 = xsi_int_to_mem(*((int *)t12));
    t14 = xsi_string_variable_get_image(t10, t11, t13);
    t15 = (t10 + 12U);
    t16 = *((unsigned int *)t15);
    xsi_report(t14, t16, 0);
    xsi_set_current_line(98, ng0);
    t2 = (t0 + 2208U);
    t3 = *((char **)t2);
    t2 = (t0 + 6602);
    t17 = *((int *)t2);
    t18 = (t17 - 9);
    t16 = (t18 * -1);
    xsi_vhdl_check_range_of_index(9, 0, -1, *((int *)t2));
    t19 = (1U * t16);
    t20 = (0 + t19);
    t11 = (t3 + t20);
    t21 = *((unsigned char *)t11);
    t12 = (t0 + 3888);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t22 = *((char **)t15);
    *((unsigned char *)t22) = t21;
    xsi_driver_first_trans_fast(t12);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 2088U);
    t3 = *((char **)t2);
    t4 = *((int64 *)t3);
    t2 = (t0 + 3248);
    xsi_process_wait(t2, t4);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB10:    t2 = (t0 + 6602);
    t8 = *((int *)t2);
    t3 = (t0 + 6606);
    t9 = *((int *)t3);
    if (t8 == t9)
        goto LAB11;

LAB16:    t17 = (t8 + 1);
    t8 = t17;
    t11 = (t0 + 6602);
    *((int *)t11) = t8;
    goto LAB8;

LAB12:    goto LAB10;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

LAB17:    goto LAB2;

LAB18:    goto LAB17;

LAB20:    goto LAB18;

}


extern void work_a_0406427775_2372691052_init()
{
	static char *pe[] = {(void *)work_a_0406427775_2372691052_p_0,(void *)work_a_0406427775_2372691052_p_1};
	xsi_register_didat("work_a_0406427775_2372691052", "isim/test_rs232_receiver_isim_beh.exe.sim/work/a_0406427775_2372691052.didat");
	xsi_register_executes(pe);
}
